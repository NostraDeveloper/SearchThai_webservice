﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace Search_Service_POI
{
    public class _prop_SnapLtrans
    {
        public int index_shape;
        public double lattitude_on_line;
        public double lontitude_on_line;
        public string[] data_db;
        public DataTable dt;
        public double snap_distance;
        public double calculate_length_line;
        public double distance_snap_to_end;
        public double distance_snap_to_start;
        public double tVal;
        public string side_of_line;
        public double lat_start;
        public double lat_end;
        public double lon_start;
        public double lon_end;
    }
}